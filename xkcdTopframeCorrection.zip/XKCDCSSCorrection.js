if (document.title.indexOf("xkcd") != -1) {
document.getElementById("bgRight").style.width="575px";
document.getElementById("topContainer").style.width="783px";
}